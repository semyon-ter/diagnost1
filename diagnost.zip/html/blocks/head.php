
<header data-top_offset="50" data-bg_color="#5922e1" class="navi navi_top">
	<div class="navi__container"><span class="menu-open"></span>
		<ul class="navi__menu menu"><span class="menu-close"></span>
			<li class="menu-item"><a href="./">Главная</a></li>
			<li class="menu-item menu-item-has-children"><a href="./">Принципы работы</a>
				<ul class="sub-menu">
					<li class="menu-item"><a href="./">Consectetur</a></li>
					<li class="menu-item"><a href="./">Adipisicing</a></li>
					<li class="menu-item"><a href="./">Reprehenderit</a></li>
					<li class="menu-item"><a href="./">Ipsum dolor</a></li>
				</ul>
			</li>
			<li class="menu-item menu-item-has-children"><a href="./">Чекапы</a>
				<ul class="sub-menu">
					<li class="menu-item"><a href="./">Базовый</a></li>
					<li class="menu-item"><a href="./">Полный</a></li>
					<li class="menu-item"><a href="./">Метабокардио</a></li>
					<li class="menu-item"><a href="./">Сон</a></li>
					<li class="menu-item"><a href="./">Витамин D</a></li>
				</ul>
			</li>
			<li class="menu-item"><a href="./">Приложение</a></li>
			<li class="menu-item"><a href="./">FAQ</a></li>
			<li class="menu-item"><a href="./">О нас</a></li>
			<li class="menu-item"><a href="./">Контакты</a></li>
		</ul>
		<div class="navi__lang"><a href="./" class="navi__lang-active">RU</a><a href="./">EN</a></div><a href="./" class="navi__login"></a><a href="./" class="navi__cart"><span class="navi__cart-counter navi__cart-counter_noempty">99</span></a>
	</div>
</header>