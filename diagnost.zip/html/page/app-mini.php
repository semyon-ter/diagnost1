
<section class="page-wrapper section section_application page_app-mini">
	<div class="section__content page-container page-container_pad-1">
		<div class="flex f-middle f-between f-flexDir-mob-column">
			<div class="section__article section__article_width-1">
				<div class="border-decor border-decor__child border-decor__color-3 p__mb-none">
					<p>ДИАГНОСТ заботится о вашем здоровье, и вы можете делать это не выходя из дома или будучи занятым на работе. Выберите свой тест, следуйте инструкциям, а мы сделаем все остальное.</p>
				</div>
			</div>
			<div class="icon ic-appstore-o indent_mlmt-1 f-shrink-0"></div>
		</div>
	</div>
</section>