
<section class="page-wrapper section page_plus page_plus__back-2">
	<div class="section__content page-container page-container_pad-1">
		<h2 class="section__title title title_color-1">5 основных<span>преимуществ</span></h2>
	</div>
	<div class="section__content section__content_wide v2 how__items border-decor border-decor__child border-decor__color-3 border-decor__tac">
		<div class="how__item">
			<div class="how__item-number t t-color3 mb-20">1</div>
			<div class="how__item-text t t-color4">
				<p>Высокоспецифичный и чувствительный анализ сухой крови имеет высокую корреляцию с обычными сывороточными анализами для профилактики ССЗ.</p>
			</div>
		</div>
		<div class="how__item">
			<div class="how__item-number t t-color3 mb-20">2</div>
			<div class="how__item-text t t-color4">
				<p>Интуитивно простой и безболезненный тест, позволяющий быстро собрать несколько капель крови из пальца на специальную фильтровальную бумагу из набора.</p>
			</div>
		</div>
		<div class="how__item">
			<div class="how__item-number t t-color3 mb-20">3</div>
			<div class="how__item-text t t-color4">
				<p>Образцы сухой крови стабильны в течение нескольких недель и имеют очень небольшой риск инфекционных заболеваний, таких как ВИЧ, так как они инактивируются в сухом виде.</p>
			</div>
		</div>
		<div class="how__item">
			<div class="how__item-number t t-color3 mb-20">4</div>
			<div class="how__item-text t t-color4">
				<p>Не требуется никаких лабораторных или дополнительных расходов на доставку.</p>
			</div>
		</div>
		<div class="how__item">
			<div class="how__item-number t t-color3 mb-20">5</div>
			<div class="how__item-text t t-color4">
				<p>Опционально, на основе комплексного теста Метабокардио чекап можно будет получить консультации с известными медицинскими экспертами и создать индивидуальную программу лечения.</p>
			</div>
		</div>
	</div>
</section>