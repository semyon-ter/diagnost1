
<section class="page-wrapper section page_plus">
	<div class="section__content page-container page-container_pad-1">
		<h2 class="section__title title title_color-1">Преимущества приложения<span>diagnost</span></h2>
	</div>
	<div class="section__content section__content_wide v2 how__items border-decor border-decor__child border-decor__color-3 border-decor__tac">
		<div class="how__item">
			<div class="how__item-number t t-color3 mb-20">1</div>
			<div class="how__item-text t t-color4">
				<p>Современное и легкое в понимании приложение ДИАГНОСТ поможет вам интуитивно выбрать правильный тест на основе ваших симптомов и личных параметров вашего здоровья</p>
			</div>
		</div>
		<div class="how__item">
			<div class="how__item-number t t-color3 mb-20">2</div>
			<div class="how__item-text t t-color4">
				<p>Наше приложение упрощает доступ к вашему личному трекеру здоровья на платформе диагностики в любом месте</p>
			</div>
		</div>
		<div class="how__item">
			<div class="how__item-number t t-color3 mb-20">3</div>
			<div class="how__item-text t t-color4">
				<p>У вас будет доступ к БЕСПЛАТНОЙ проверке состояния здоровья БАЗОВЫЙ ЧЕКАП с подробным объяснением ваших параметров в приложении</p>
			</div>
		</div>
		<div class="how__item">
			<div class="how__item-number t t-color3 mb-20">4</div>
			<div class="how__item-text t t-color4">
				<p>Легко выбрать, заказать и приобрести любой тест; наши тесты просты и не инвазивны, с четкими инструкциями</p>
			</div>
		</div>
		<div class="how__item">
			<div class="how__item-number t t-color3 mb-20">5</div>
			<div class="how__item-text t t-color4">
				<p>Каждый тест анализируется и интерпретируется командой экспертов в области превентивной медицины; подробный визуальный отчет доступен в приложении</p>
			</div>
		</div>
	</div>
</section>