<?php
$SECTIONS = array();
$SECTIONS[] = 'blocks/head';
$SECTIONS[] = 'blocks/fake-head';
$SECTIONS[] = 'page/app';
$SECTIONS[] = 'page/plus';
$SECTIONS[] = 'page/app-mini';
$SECTIONS[] = 'footer';
$SECTIONS[] = 'blocks/social';
include_once("html/header.php");