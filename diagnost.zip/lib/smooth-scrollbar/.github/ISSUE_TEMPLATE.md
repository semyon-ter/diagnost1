<!-- Provide a general summary of the issue in the Title above -->
## Environment
- Browser:
- Version of smooth-scrollbar:

## Issue Summary
<!-- A summary of the issue and the browser/OS environment in which it occurs.  -->

## Current Behavior
<!-- If describing a bug, tell me what happens instead of the expected behavior -->


## Expected Behavior
<!-- If you're describing a bug, tell me what should happen -->
<!-- If you're suggesting a change/improvement, tell me how it should work -->

## Steps to Reproduce
<!-- Tell me how it happened -->

## Online demo
<!--
  Create an example on codepan.net:
    1. Open https://codepan.net/gist/4653b46f9e2d4c2f3585cebc1828859d
    2. Modify the code as you want
    3. Click "..." on the top right
    4. Click "Save Anonymous Gist" (or "Save New Gist" if you've logged in)
    5. Copy and paste the URL here
-->
