<?php
$SECTIONS = array();
$SECTIONS[] = 'blocks/head';
$SECTIONS[] = 'blocks/fake-head';
$SECTIONS[] = 'page/about';
$SECTIONS[] = 'page/partner';
$SECTIONS[] = 'footer';
$SECTIONS[] = 'blocks/social';
include_once("html/header.php");